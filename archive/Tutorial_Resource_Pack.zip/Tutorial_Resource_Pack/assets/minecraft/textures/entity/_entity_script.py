import os, sys
from PIL import Image

prog_path = sys.path[0]

for directory_name in os.listdir():
	if "." not in directory_name:
		os.chdir(prog_path+"\\"+directory_name)
		for file_name in os.listdir():
			if file_name.endswith(".png"):
				image = Image.open(file_name).convert("RGB")
				width, height = image.size
				out = Image.new("RGB", (width, height))
				for x in range(width):
					for y in range(height):
						out.putpixel((x, y), (255, 0, 0))
				out.save(file_name)
		os.chdir(prog_path)