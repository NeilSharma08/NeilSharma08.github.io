import os
from PIL import Image
for file_name in os.listdir():
	if file_name.endswith(".png"):
		image = Image.open(file_name).convert("RGB")
		width, height = image.size
		out = Image.new("RGB", (width, height))
		for x in range(width):
			for y in range(height):
				red = 1 if 0 in [x,y] or x % 16 == 15 or y % 16 == 15 else 0
				out.putpixel((x, y), (255 if red else 0, 0, 0))
		out.save(file_name)